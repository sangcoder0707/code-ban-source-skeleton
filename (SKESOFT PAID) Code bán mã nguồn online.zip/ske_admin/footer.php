    <script>
        $(document).ready(function() {
          $('#ske_edit').summernote();
          $('#ske_create').summernote();
          $('.table').DataTable();
      });
  </script>
  <footer>
   <?php
   $color = rand(100000,980000);
   ?>
   <h4 class="h4 text-center mt-4" style="color: #<?=$color?>">&copy; 2021 - Ske Software</h4>
</footer>
</body>
</html>