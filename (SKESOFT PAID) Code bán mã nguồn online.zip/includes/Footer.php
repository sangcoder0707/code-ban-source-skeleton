<?php
// CHECK IF DOESNT'T PREMISSION
if (!isset($access)) {
  die("no permission to access");
}
?>
<footer class="footer pt-3 bg-white shadow rounded-3">
  <div class="container-fluid">
    <div class="row align-items-center justify-content-lg-between">
      <div class="col-lg-6 mb-lg-0 mb-4">
        <div class="copyright text-center text-sm text-muted text-lg-start">
          © 2021 - <?= date('Y') ?> - <a href="https://facebook.com/skesoftware" target="_blank">Ske Software</a>
          <p class="text-sm mt-1 text-muted"><i class="fal fa-code-branch"></i>&nbsp;Version 2.2 - Made by <a href="https://facebook.com/vinhuptoday" target="_blank" style="text-decoration: underline !important;">Vinh Corp</a> with ❤️</p>
        </div>
      </div>
      <div class="col-lg-6">
        <ul class="nav nav-footer justify-content-center justify-content-lg-end">
          <li class="nav-item">
            <a href="/" class="nav-link text-muted"><i class="fal fa-home"></i> Trang chủ</a>
          </li>
          <li class="nav-item">
            <a href="/terms-use" class="nav-link text-muted"><i class="fal fa-book"></i> &nbsp;Chính sách</a>
          </li>
          <li class="nav-item">
            <a href="/contact" class="nav-link text-muted"><i class="fal fa-phone"></i> Liên hệ</a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</footer>
</div>
<!-- Modal Noti -->
<div class="modal fade" id="new-noti" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h6 class="modal-title"><i class="fal fa-bell"></i> Thông báo</h6>
        <button type="button" class="btn-close text-dark" data-bs-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">
        <p>Đây là website demo code tại Ske Soft!</p>
        <p>Vui lòng truy cập <a href="https://vinhsoft.com">vinhsoft.com</a> để biết thêm thông tin</p>
        <p>Truy cập admin <a href="/ske_admin">tại đây</a></p>
        <p>Tk và mk quản trị đều là <b>admin</b></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn bg-gradient-primary" data-bs-dismiss="modal" id="close_modal_forever">Không hiển thị lại</button>
        <button type="button" class="btn btn-link ml-auto" data-bs-dismiss="modal">Đóng</button>
      </div>
    </div>
  </div>
</div>
</main>
<!--   Core JS Files   -->
<script src="/assets/js/core/popper.min.js"></script>
<script src="/assets/js/core/bootstrap.min.js"></script>
<script src="/assets/js/plugins/perfect-scrollbar.min.js"></script>
<script src="/assets/js/plugins/smooth-scrollbar.min.js"></script>
<!-- Clipboard JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.8/clipboard.min.js"></script>
<script>
  new ClipboardJS('.copy');
  $(".copy").click(function() {
    $(this).html("Đã sao chép !");
    setTimeout(() => {
      $(this).html('<i class="fa-thin fa-clipboard"></i> Sao chép');
    }, 500);
  });
  $(function() {
    if (!Cookies.get('modal_auto_open')) {
      // Auto Open Modal
      $("#new-noti").modal('show');
    } else {
      $("#close_modal_forever").hide();
    }
    $("#close_modal_forever").click(function() {
      Cookies.set('modal_auto_open', false);
      $(this).hide();
    });
    setInterval(() => {
      if (!(window.navigator.onLine)) {
        Swal.fire({
          icon: 'error',
          title: 'Lỗi mạng',
          text: 'Thử kết nối lại mạng của bạn !',
          footer: 'Kiểm tra kết nối mạng của bạn và tải lại trang để khắc phục'
        })
      }
    }, 5000);
    var win = navigator.platform.indexOf('Win') > -1;
    if (win && document.querySelector('#sidenav-scrollbar')) {
      var options = {
        damping: '0.5'
      }
      Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
    }
  });
</script>

<!-- Github buttons -->
<script async defer src="https://buttons.github.io/buttons.js"></script>
<!-- Control Center for Soft Dashboard: parallax effects, scripts for the example pages etc -->
<script src="/assets/js/soft-ui-dashboard.min.js?v=1.0.3"></script>
</body>

</html>