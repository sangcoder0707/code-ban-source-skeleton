<?php
include $_SERVER['DOCUMENT_ROOT'] . '/includes/Config.php';
$access = 1;
$title = 'Mã hóa PHP | Ske Software';
include '../includes/Header.php';
?>
<div class="container-fluid py-4">
  <div class="row mt-4">
    <div class="col-lg-7 mb-lg-0 mb-4">
      <div class="card">
        <div class="card-body p-3">
          <div class="row">
            <div class="col-lg-6">
              <div class="d-flex flex-column h-100">
                <p class="mb-1 pt-2 text-bold"><i class="fad fa-badge-dollar"></i> Ske Software</p>
                <h5 class="font-weight-bolder">Kiếm tiền từ đây</h5>
                <p class="mb-5">Hành trình kiếm tiền của bạn bắt đầu từ đây - Kiếm tiền bằng Website MMO</p>
              </div>
            </div>
            <div class="col-lg-5 ms-auto text-center mt-5 mt-lg-0">
              <div class="border-radius-lg h-100">
                <img src="/assets/img/shapes/waves-white.svg" class="position-absolute h-100 w-50 top-0 d-lg-block d-none" alt="waves">
                <div class="position-relative d-flex align-items-center justify-content-center h-100">
                  <img class="w-50 position-relative z-index-2 pt-4" src="/assets/img/dollar.png" alt="rocket">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-5">
      <div class="card h-100 p-3">
        <div class="overflow-hidden position-relative border-radius-lg bg-cover h-100" style="background-image: url('/assets/img/ivancik.jpg');">
          <span class="mask bg-gradient-dark"></span>
          <div class="card-body position-relative z-index-1 d-flex flex-column h-100 p-3">
            <h5 class="text-white font-weight-bolder mb-4 pt-2"><i class="fa-brands fa-php"></i> Mã hóa PHP</h5>
            <p class="text-white">Bảo mật an toàn code PHP của bạn bằng cách mã hóa nó !</p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="row my-4">
    <div class="col-xl-12">
      <div class="card h-100">
        <div class="card-body p-3">
          <h4 class="h5 text-muted text-center mt-3 mb-5">Công cụ mã hóa code PHP</h4>
          <div class="row g-4 mb-4">
            <div class="col-lg-6">
              <div class="card shadow-sm">
                <div class="card-header border-bottom-0 p-4">
                  <h3 class="card-title">Mã hóa PHP</h3>
                </div>
                <div class="card-body px-4">
                  <div class="intro">Dán PHP cần mã hóa của bạn vào dưới đây:</div>
                  <p class="fw-bold">Lưu ý: Không cần &lt;?php ?&gt; khi dán code PHP của bạn vào bên dưới</p>
                  <b>&lt;?php</b>
                  <div class="form-group mt-2 mb-2">
                    <textarea id="php_origial" style="height: 500px" class="form-control" placeholder='echo "Dán mã PHP của bạn vào đây";'></textarea>
                  </div>
                  <b>?&gt;</b>
                </div>
                <div class="card-footer p-4 mt-auto">
                  <button class="btn btn-primary" id="btn_encode"><i class="fa-thin fa-play"></i> Mã hóa ngay</button>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="card shadow-sm">
                <div class="card-header border-bottom-0 p-4">
                  <h3 class="card-title">Kết quả</h3>
                </div>
                <div class="card-body px-4">
                  <p class="intro">Mã PHP đã mã hóa của bạn ở dưới đây! Copy và dán nó vào tệp PHP.</p>
                  <div class="form-group">
                    <textarea id="php_encoded" readonly style="height: 500px" class="form-control" placeholder='PHP đã mã hóa sẽ hiện tại đây'></textarea>
                  </div>
                </div>
                <div class="card-footer p-4 mt-auto">
                  <button class="btn btn-secondary copy" data-clipboard-action="copy" data-clipboard-target="#php_encoded"><i class="fa-thin fa-clipboard"></i> Sao chép</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
  $("#btn_encode").click(function() {
    if ($("#php_origial").val().length <= 5) {
      Swal.fire('Lỗi', 'Mã bạn nhập vào quá ngắn !', 'error');
    } else {
      $(this).html('Đang mã hóa');
      $(this).prop('disabled', true);
      $.ajax({
        type: "post",
        url: "/apis/Php_encode.php",
        data: {
          org_php: $("#php_origial").val()
        },
        dataType: "json",
        success: function(response) {
          if (!response['status']) {
            $("#btn_encode").html('<i class="fa-thin fa-play"></i> Mã hóa ngay');
            Swal.fire('Lỗi', response['msg'], 'error');
            $("#btn_encode").prop('disabled', false);
          } else {
            $("#btn_encode").html('<i class="fa-thin fa-play"></i> Mã hóa ngay');
            Swal.fire('Thành công', response['msg'], 'success');
            $("#btn_encode").prop('disabled', false);
            $("#php_encoded").val(response['php_encoded']);
          }
        }
      });
    }
  });
</script>
<?php include '../includes/Footer.php'; ?>