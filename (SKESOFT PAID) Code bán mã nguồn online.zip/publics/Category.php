<?php
include $_SERVER['DOCUMENT_ROOT'].'/includes/Config.php';
$access = 1;
$title = 'Danh mục code | Ske Software';
include '../includes/Header.php';
?>
<div class="container-fluid py-4">
	<div class="row mt-4">
		<div class="col-lg-7 mb-lg-0 mb-4">
			<div class="card">
				<div class="card-body p-3">
					<div class="row">
						<div class="col-lg-6">
							<div class="d-flex flex-column h-100">
								<p class="mb-1 pt-2 text-bold"><i class="fad fa-badge-dollar"></i> Ske Software</p>
								<h5 class="font-weight-bolder">Kiếm tiền từ đây</h5>
								<p class="mb-5">Hành trình kiếm tiền của bạn bắt đầu từ đây - Kiếm tiền bằng Website MMO</p>
							</div>
						</div>
						<div class="col-lg-5 ms-auto text-center mt-5 mt-lg-0">
							<div class="border-radius-lg h-100">
								<img src="/assets/img/shapes/waves-white.svg" class="position-absolute h-100 w-50 top-0 d-lg-block d-none" alt="waves">
								<div class="position-relative d-flex align-items-center justify-content-center h-100">
									<img class="w-50 position-relative z-index-2 pt-4" src="/assets/img/dollar.png" alt="rocket">
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-lg-5">
			<div class="card h-100 p-3">
				<div class="overflow-hidden position-relative border-radius-lg bg-cover h-100" style="background-image: url('/assets/img/ivancik.jpg');">
					<span class="mask bg-gradient-dark"></span>
					<div class="card-body position-relative z-index-1 d-flex flex-column h-100 p-3">
						<h5 class="text-white font-weight-bolder mb-4 pt-2">Kiếm tiền thật dễ dàng</h5>
						<p class="text-white">Danh mục mã nguồn có trên website chúng tôi</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="row my-4">
		<div class="col-xl-12">
			<div class="card h-100">
				<div class="card-body p-3">
					<h4 class="h5 text-muted text-center mt-3 mb-1">DANH MỤC</h4>
					<center><p style="border-bottom: 1px solid greenyellow; width: 140px;"></p></center>
					<center>
						<div class="col-sm-5">
							<!-- Search Style -->
							<style>
								.form {
									position: relative;
								}
								.form .fa-search {
									position: absolute;
									top: 20px;
									left: 20px;
									color: #9ca3af;
								}
								.form span {
									position: absolute;
									right: 17px;
									top: 13px;
									padding: 2px;
									border-left: 1px solid #d1d5db;
								}
								.form-input {
									height: 55px;
									text-indent: 33px;
									border-radius: 50px;
								}
								.form-input:focus {
									box-shadow: none;
									border: none;
								}
								.left-pan {
									padding-left: 7px;
								}
								.left-pan i {
									padding-left: 10px;
								}
							</style>
							<form id="search_form">
								<div class="row height d-flex justify-content-center align-items-center">
									<div class="col-md-10">
										<div class="form">
											<i class="fa fa-search"></i>
											<input type="text" class="form-control form-input" placeholder="Tìm danh mục" id="search_input">
											<button type="submit" style="background: transparent; border: none"><span class="left-pan"><i class="fal fa-sign-in"></i></span></button>
										</div>
									</div>
								</div>
							</form>
						</div>
					</center>
					<!-- List Product in Shadow Card -->
					<div class="card shadow" style="box-shadow: 0 0.25rem 6rem -0.0625rem rgb(20 20 20 / 12%), 0 0.125rem 0.25rem -0.0625rem rgb(20 20 20 / 7%) !important">
						<div class="card-body">
							<p class="text-center text-sm text-muted" id="searching_text" style="display: none;"><i class="fas fa-circle-notch fa-spin"></i> &nbsp;Đang tìm kiếm</p>
							<div class="row" id="list_code">	
								<?php
								foreach (GetCategory() as $result) : ?>
									<div class="col-sm-4">
										<div class="card mt-2">
											<div class="card-header p-0 mx-3 mt-3 position-relative z-index-1">
												<a href="/view-category/<?=$result['link']?>" class="d-block">
													<center><img src="<?=$result['image']?>" class="img-fluid img-thumbnail"></center>
												</a>
											</div>
											<div class="card-body pt-2">
												<center><div class="dropdown-divider mb-2" style="border-top: 1px solid rgb(0 255 31 / 20%) !important; width: 123px;"></div></center>
												<span class="text-gradient text-primary text-uppercase text-xs font-weight-bold my-2">MÃ DANH MỤC: #<?=$result['id']?></span>
												<a href="/view-category/<?=$result['link']?>" class="card-title h5 d-block text-darker">
													<?=$result['name']?>
												</a>
												<p class="card-description mb-4 text-sm">
													<?=$result['description']?>
												</p>
												<center><a class="btn btn-outline-secondary" href="/view-category/<?=$result['link']?>"><i class="fal fa-search"></i> &nbsp;Xem ngay</a></center>
											</div>
										</div>
									</div>
								<?php endforeach; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Product Script -->
	<script>
		$(function() {
			$("#search_form").submit(function (e) {
				e.preventDefault();
				$("#list_code").empty();
				$("#searching_text").show();
				$.ajax({
					url: '/apis/SearchCategory.php',
					type: 'post',
					data: {search_code: $("#search_input").val(), search_code_submit: 1},
					success: function(res) {
						setTimeout(function() {
							$("#list_code").html(res);
							$("#searching_text").hide('fast');
						},800);
					}
				});
			});
		});
	</script>
	<?php include '../includes/Footer.php';?>