<?php
include $_SERVER['DOCUMENT_ROOT'] . '/includes/Config.php';
if (!isset($_GET['code'])) {
	die(header("Location: /category"));
}
$access = 1;
$code = PreventSql($_GET['code']);
$getInfo = $ske_connect->query("SELECT * FROM sources WHERE name_id = '$code' ")->fetch_array();
if (!isset($getInfo['name_id'])) {
	die(header("Location: /category"));
}
$title = $getInfo['name'] . ' | Ske Software';
$ske_connect->query("UPDATE sources SET viewer = viewer + 1 WHERE name_id = '$code'");
include '../includes/Header.php';
?>
<!-- Viewer JS -->
<div id="imageviewer"></div>
<div class="container-fluid py-4">
	<div class="row mt-4">
		<div class="col-lg-7 mb-lg-0 mb-4">
			<div class="card">
				<div class="card-body p-3">
					<div class="row">
						<div class="col-lg-6">
							<div class="d-flex flex-column h-100">
								<p class="mb-1 pt-2 text-bold"><i class="fad fa-badge-dollar"></i> Ske Software</p>
								<h5 class="font-weight-bolder">Kiếm tiền từ đây</h5>
								<p class="mb-5">Hành trình kiếm tiền của bạn bắt đầu từ đây - Kiếm tiền bằng Website MMO</p>
							</div>
						</div>
						<div class="col-lg-5 ms-auto text-center mt-5 mt-lg-0">
							<div class="border-radius-lg h-100">
								<img src="/assets/img/shapes/waves-white.svg" class="position-absolute h-100 w-50 top-0 d-lg-block d-none" alt="waves">
								<div class="position-relative d-flex align-items-center justify-content-center h-100">
									<img class="w-50 position-relative z-index-2 pt-4" src="/assets/img/dollar.png" alt="rocket">
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-lg-5">
			<div class="card h-100 p-3">
				<div class="overflow-hidden position-relative border-radius-lg bg-cover h-100" style="background-image: url('/assets/img/ivancik.jpg');">
					<span class="mask bg-gradient-dark"></span>
					<div class="card-body position-relative z-index-1 d-flex flex-column h-100 p-3">
						<h5 class="text-white font-weight-bolder mb-4 pt-2">Xem mã nguồn</h5>
						<p class="text-white"><?= $getInfo['name'] ?></p>
						<a class="text-white text-sm font-weight-bold mb-0 icon-move-right mt-auto" onclick="history.back();" href="#">
							<i class="fas fa-arrow-left text-sm ms-1" aria-hidden="true"></i> &nbsp;Quay lại danh mục</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="row my-4">
		<div class="col-xl-8">
			<div class="card">
				<div class="card-body p-3">
					<h4 class="h5 text-muted text-center mt-3 mb-3"><?= $getInfo['name'] ?></h4>
					<style>
						#images img {
							cursor: pointer;
							max-width: 100%;
							height: auto
						}
					</style>
					<div id="images">
						<p><?= $getInfo['details'] ?></p>
					</div>
				</div>
			</div>
			<div class="card shadow mt-3">
				<div class="card-body">
					<h5 class="h5 text-center fw-bold"><i class="far fa-exclamation-circle"></i> CHÚ Ý</h5>
					<ul>
						<li>Hãy đừng tiếc tiền mà lấy code trên mạng hoặc bên thứ 3 về dùng.</li>
						<li>Code trên mạng sẽ gắn keylog, mã độc, ... Khi dùng sẽ bị mất tiền hoặc đánh cắp thông tin quan trọng của bạn.</li>
						<li>Hãy mua code an toàn, đảm bảo tại đây!</li>
						<li>Trong trường hợp dùng code share chúng tôi sẽ không hỗ trợ bất cứ gì về code này.</li>
					</ul>
				</div>
			</div>
		</div>
		<div class="col-xl-4 mt-2">
			<div style="position: sticky; top: 3px;">
				<div class="card bg-gray">
					<div class="card-body">
						<h4 class="h5 fw-bold" style="text-align: left;"><i class="fal fa-shopping-cart" style="color: blueviolet;"></i> Mua code</h4>
						<br>
						<center><span class="fw-bold"><i class="fal fa-money-bill-alt"></i> Giá tiền: <span class="fw-bold h4"><?= CheckPrice($getInfo['price']) ?></span></span></center>
						<br>
						<p><i class="fal fa-shield-check" style="color: yellowgreen;"></i> Tên code: <?= $getInfo['name'] ?></p>
						<p><i class="fal fa-shield-check" style="color: yellowgreen;"></i> Ngày phát hành: <?= date('d/m/Y', strtotime($getInfo['time_created'])) ?></p>
						<p><i class="fal fa-shield-check" style="color: yellowgreen;"></i> Được nén bằng ZIP</p>
						<br>
						<?php if ($getInfo['price'] <= 0) { ?>
							<center><button type="button" style="font-size: 20px;" class="btn btn-outline-info" disabled=""><i class="fal fa-shopping-cart"></i> MIỄN PHÍ</button></center>
						<?php } else { ?>
							<center><a style="font-size: 20px;" class="btn btn-outline-danger" href="/contact" target="_blank"><i class="fal fa-shopping-cart"></i> MUA NGAY</a></center>
						<?php } ?>
					</div>
				</div>
				<?php
				if ($getInfo['price'] > 0) : ?>
					<div class="card bg-gray mt-2 shadow" style="position: sticky; top: 62px;">
						<div class="card-body">
							<h4 class="h5 fw-bold" style="text-align: left;"><i class="fal fa-shield-check" style="color: yellowgreen;"></i> Cam kết</h4>
							<br>
							<p><i class="fal fa-shield-check" style="color: yellowgreen;"></i> Bảo hành 1 đổi 1 nếu gặp vấn đề</p>
							<p><i class="fal fa-shield-check" style="color: yellowgreen;"></i> Cập nhật code bất cứ lúc nào</p>
							<p><i class="fal fa-shield-check" style="color: yellowgreen;"></i> Code được đóng gói trong: ZIP</p>
							<p><i class="fal fa-shield-check" style="color: yellowgreen;"></i> Toàn bộ code được quý khách làm chủ, không mã hóa, không bản quyền chân trang của code</p>
							<p><i class="fal fa-shield-check" style="color: yellowgreen;"></i> Hỗ trợ setup code qua UltraView hoặc TeamView</p>
							<p><i class="fal fa-shield-check" style="color: yellowgreen;"></i> Có thể yêu cầu thêm tính năng (nếu cần)</p>
						</div>
					</div>
				<?php endif ?>
			</div>
		</div>
	</div>
	<!-- Viewer JS View Image -->
	<script>
		// View an image.
		const viewer = new Viewer(document.getElementById('images'), {
			inline: false,
			viewed() {
				viewer.zoomTo(1);
			},
		});
		const gallery = new Viewer(document.getElementById('imageviewer'));
	</script>
	<?php include '../includes/Footer.php'; ?>