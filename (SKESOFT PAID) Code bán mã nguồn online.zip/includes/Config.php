<?php
/**
 * @author Developer By Ske Software
 */
$config = array(
	'host' => 'localhost',
	'user' => 'root',
	'pass' => '1234567890A!',
	'database' => 'skesoft_web'
);
$ske_connect = mysqli_connect($config['host'],$config['user'],$config['pass'],$config['database']) or die("Falied to connect database");
if ($ske_connect) {
	mysqli_query($ske_connect,"SET NAMES utf8");
}
date_default_timezone_set('Asia/Ho_Chi_Minh');
/**
 * @package Functions Here
 */
function GetCodes($category_id) {
	global $ske_connect;
	$query = mysqli_query($ske_connect,"SELECT * FROM sources WHERE category_id = $category_id ORDER BY time_created DESC");
	return $query;
}
function GetAllCodes() {
	global $ske_connect;
	$query = mysqli_query($ske_connect,"SELECT * FROM sources ORDER BY time_created DESC");
	return $query;
}
function GetCategory() {
	global $ske_connect;
	$query = mysqli_query($ske_connect,"SELECT * FROM category");
	return $query;
}
function MoneyFormat($price) {
	return str_replace(",", ".", number_format($price));
}
function PreventSql($string) {
	global $ske_connect;
	return mysqli_real_escape_string($ske_connect,$string);
}
function CheckPrice($price) {
	if ($price <= 0) {
		echo 'Miễn phí';
	} else {
		echo MoneyFormat($price).' Đ';
	}
}
function short_number( $n, $precision = 1 ) {
	if ($n < 900) {
		// 0 - 900
		$n_format = number_format($n, $precision);
		$suffix = '';
	} else if ($n < 900000) {
		// 0.9k-850k
		$n_format = number_format($n / 1000, $precision);
		$suffix = 'K';
	} else if ($n < 900000000) {
		// 0.9m-850m
		$n_format = number_format($n / 1000000, $precision);
		$suffix = 'M';
	} else if ($n < 900000000000) {
		// 0.9b-850b
		$n_format = number_format($n / 1000000000, $precision);
		$suffix = 'B';
	} else {
		// 0.9t+
		$n_format = number_format($n / 1000000000000, $precision);
		$suffix = 'T';
	}

  // Remove unecessary zeroes after decimal. "1.0" -> "1"; "1.00" -> "1"
  // Intentionally does not affect partials, eg "1.50" -> "1.50"
	if ( $precision > 0 ) {
		$dotzero = '.' . str_repeat( '0', $precision );
		$n_format = str_replace( $dotzero, '', $n_format );
	}

	return $n_format . $suffix;
}