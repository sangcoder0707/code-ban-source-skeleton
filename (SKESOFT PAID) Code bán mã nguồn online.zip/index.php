<?php
$access = true;
$title = 'Ske Software - Thiết kế website cho bạn kiếm tiền - MMO Method';
include 'includes/Header.php';
?>
<div class="container-fluid py-4">
  <div class="row mt-4">
    <div class="col-lg-7 mb-lg-0 mb-4">
      <div class="card">
        <div class="card-body p-3">
          <div class="row">
            <div class="col-lg-6">
              <div class="d-flex flex-column h-100">
                <p class="mb-1 pt-2 text-bold"><i class="fad fa-badge-dollar"></i> Ske Software</p>
                <h5 class="font-weight-bolder">Kiếm tiền từ đây</h5>
                <p class="mb-5">Hành trình kiếm tiền của bạn bắt đầu từ đây - Kiếm tiền bằng Website MMO</p>
              </div>
            </div>
            <div class="col-lg-5 ms-auto text-center mt-5 mt-lg-0">
              <div class="border-radius-lg h-100">
                <img src="/assets/img/shapes/waves-white.svg" class="position-absolute h-100 w-50 top-0 d-lg-block d-none" alt="waves">
                <div class="position-relative d-flex align-items-center justify-content-center h-100">
                  <img class="w-50 position-relative z-index-2 pt-4" src="/assets/img/dollar.png" alt="rocket">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-lg-5">
      <div class="card h-100 p-3">
        <div class="overflow-hidden position-relative border-radius-lg bg-cover h-100" style="background-image: url('/assets/img/ivancik.jpg');">
          <span class="mask bg-gradient-dark"></span>
          <div class="card-body position-relative z-index-1 d-flex flex-column h-100 p-3">
            <h5 class="text-white font-weight-bolder mb-4 pt-2">Kiếm tiền thật dễ dàng</h5>
            <p class="text-white">Xây dựng 1 website cho riêng mình & kèm mã nguồn chỉ vài thao tác.</p>
            <a class="text-white text-sm font-weight-bold mb-0 icon-move-right mt-auto" href="/category">
              Xem mã nguồn
              <i class="fas fa-arrow-right text-sm ms-1" aria-hidden="true"></i>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="row my-4">
    <div class="col-xl-6">
      <div class="card h-100">
        <div class="card-body p-3">
          <h4 class="h5 text-muted text-center mt-3 mb-3">VÌ SAO CHỌN SKE SOFTWARE ?</h4>
          <div class="timeline timeline-one-side">
            <div class="timeline-block mb-3">
              <span class="timeline-step">
                <i class="fas fa-clock text-success"></i>
              </span>
              <div class="timeline-content">
                <h6 class="text-dark text-sm font-weight-bold mb-0">Tiết kiệm thời gian</h6>
                <p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Chúng tôi coi thời gian của bạn như vàng bạc ! Hãy xem 1 số code có sẵn cho bạn tha hồ lựa chọn</p>
              </div>
            </div>
            <div class="timeline-block mb-3">
              <span class="timeline-step">
                <i class="fad fa-allergies"></i>
              </span>
              <div class="timeline-content">
                <h6 class="text-dark text-sm font-weight-bold mb-0">Dễ dàng sử dụng !</h6>
                <p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Đội ngũ chúng tôi luôn sẵn sàng giúp đỡ bạn khi có vấn đề khi sử dụng code của chúng tôi</p>
              </div>
            </div>
            <div class="timeline-block mb-3">
              <span class="timeline-step">
                <i class="fad fa-wrench text-info"></i>
              </span>
              <div class="timeline-content">
                <h6 class="text-dark text-sm font-weight-bold mb-0">Cập nhật</h6>
                <p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Cập nhật mã nguồn khi liên hệ chúng tôi</p>
              </div>
            </div>
            <div class="timeline-block mb-3">
              <span class="timeline-step">
                <i class="fas fa-tools text-primary"></i>
              </span>
              <div class="timeline-content">
                <h6 class="text-dark text-sm font-weight-bold mb-0">Bảo hành</h6>
                <p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Bảo hành khi mã nguồn có vấn đề</p>
              </div>
            </div>
            <div class="timeline-block mb-3">
              <span class="timeline-step">
                <i class="fal fa-pen text-warning"></i>
              </span>
              <div class="timeline-content">
                <h6 class="text-dark text-sm font-weight-bold mb-0">Tùy chọn tính năng</h6>
                <p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Bổ sung thêm tính năng vào mã nguồn nếu bạn muốn !</p>
              </div>
            </div>
            <div class="timeline-block mb-3">
              <span class="timeline-step">
                <i class="fa-solid fa-dollar-sign"></i>
              </span>
              <div class="timeline-content">
                <h6 class="text-dark text-sm font-weight-bold mb-0">Mã nguồn miễn phí</h6>
                <p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Ngoài code trả phí, chúng tôi còn cung cấp mã nguồn miễn phí !</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-xl-6 mt-2">
      <div class="image-container">
        <img class="img-fluid" src="/assets/img/ill_dash.png" alt="alternative">
      </div>
    </div>
  </div>
  <?php include 'includes/Footer.php'; ?>