<?php
session_start();
if (isset($_SESSION['admin'])) {
	die(header("Location: /ske_admin/category.php"));
}
include 'header.php';
?>
<div class="container">
	<h4 class="h4 text-center mt-3">Please Đăng nhập Admin :-)</h4>
	<div class="row mt-3">
		<div class="col-sm-4 mx-auto">
			<form method="post">
			<div class="form-group">
				<input type="text" class="form-control" placeholder="Username" required="" name="ske_user">
			</div>
			<br>
			<div class="form-group">
				<input type="password" class="form-control" placeholder="Mật khẩu" required="" name="ske_pass">
			</div>
			<br>
			<center><button class="btn btn-primary btn-lg" type="submit" name="ske_login">Đăng nhập !</button></center>
		</div>
	</form>
	<?php
	if (isset($_POST['ske_login'])) {
		if ($_POST['ske_user'] != 'admin' || $_POST['ske_pass'] != 'admin') {
			echo 'Sai tk hoặc mk!';
		} else {
			$_SESSION['admin'] = 1;
			echo '<script>window.location.href = "/ske_admin/category.php"</script>';
		}
	}
	?>
	</div>
</div>
<?php
include 'footer.php';
?>