<?php
include '../includes/Config.php';
session_start();
if (!isset($_SESSION['admin'])) {
	die(header("Location: /ske_admin/index.php"));
} else {
	if (isset($_GET['name'])) {
		$info = $ske_connect->query("SELECT * FROM sources WHERE name_id = '$_GET[name]'")->fetch_array();
		if (empty($info)) {
			die(header("Location: /ske_admin/category.php"));
		}
	}
}
include 'header.php';
?>
<div class="container mt-4">
	<div class="row">
		<div class="col-sm-8 mx-auto">
			<form method="post">
				<h4 class="h4 text-center">Chỉnh sửa code: <?=$info['name']?></h4>
				<div class="form-group">
					<input type="text" value="<?=$info['id']?>" hidden name="id_code">
					<p>Tên code</p>
					<input type="text" class="form-control" value="<?=$info['name']?>" name="name_code"  required>
				</div>
				<br>
				<div class="form-group">
					<p>Đường liên kết</p>
					<input type="text" class="form-control" value="<?=$info['name_id']?>" name="url_code" required>
				</div>
				<br>
				<div class="form-group">
					<p>Mã code</p>
					<input type="text" class="form-control" value="<?=$info['name_code']?>" name="code_code" required>
				</div>
				<br>
				<div class="form-group">
					<p>Mệnh giá code</p>
					<input type="number" class="form-control" value="<?=$info['price']?>" name="price_code" required>
				</div>
				<br>
				<div class="form-group">
					<p>Link ảnh</p>
					<input type="text" class="form-control" value="<?=$info['image']?>" name="image_code" required>
				</div>
				<br>
				<div class="form-group">
					<label>Danh mục</label>
					<select name="category_code" class="form-control">
						<?php
						foreach (GetCategory() as $category) :
						?>
						<option value="<?=$category['id']?>" <?=$category['id'] == $info['category_id'] ? 'selected' : NULL?>><?=$category['name']?></option>
						<?php endforeach?>
					</select>
				</div>
				<div class="form-group">
					<p>Mô tả</p>
					<textarea class="form-control" name="details_code" id="ske_edit"><?=$info['details']?></textarea>
				</div>
				<br>
				<center><button type="submit" class="btn btn-primary" name="save_code">Lưu thay đổi</button>
				</form></center>
				<br>
				<?php
				if (isset($_POST['save_code'])) {
					$save = $ske_connect->query("UPDATE sources SET
						name = '$_POST[name_code]',
						name_id = '$_POST[url_code]',
						name_code = '$_POST[code_code]',
						price = '$_POST[price_code]',
						details = '$_POST[details_code]',
						category_id = $_POST[category_code],
						image = '$_POST[image_code]' WHERE id = '$_POST[id_code]'");
					if ($save) {
						echo "Save Oke";
					} else {
						echo "Save Failed";
					}
				}
				if (isset($_POST['create_new_code'])) {
					$save1 = $ske_connect->query("INSERT INTO sources SET
						name = '$_POST[name_code_new]',
						name_id = '$_POST[url_code_new]',
						name_code = '$_POST[code_code_new]',
						price = '$_POST[price_code_new]',
						details = '$_POST[details_code_new]',
						image = '$_POST[image_code_new]',
						`time_created` = now()");
					if ($save1) {
						echo "Create Oke";
					} else {
						echo "Create Failed";
					}
				}
				?>
			</div>
		</div>
	</div>
	<?php
	include 'footer.php';
?>