<?php
session_start();
if (!isset($_SESSION['admin'])) {
	die(header("Location: /ske_admin"));
}
include '../includes/Config.php';
if (isset($_GET['id'])) {
	if (!is_numeric($_GET['id'])) {
		die(header("Location: /ske_admin"));
	} else if ($ske_connect->query("SELECT * FROM category WHERE id = " . PreventSql($_GET['id']))->num_rows <= 0) {
		die(header("Location: /ske_admin"));
	}
} else {
	die(header("Location: /ske_admin"));
}
include 'header.php';
?>
<div class="container mt-4">
	<button class="btn btn-success float-right" data-toggle="modal" data-target="#create_new">TẠO MỚI CODE</button>
	<p>Bảng dữ liệu</p>
	<table class="table table-bordered hover">
		<thead>
			<tr>
				<th>Tên Code</th>
				<th>Mã Code</th>
				<th>Đường liên kết</th>
				<th>Giá Tiền</th>
				<th>Ảnh</th>
				<th>Thời Gian Tạo</th>
				<th>Lượt xem</th>
				<th>Thao Tác</th>
			</tr>
		</thead>
		<tbody>
			<?php
			foreach (GetCodes(PreventSql($_GET['id'])) as $result) { ?>
				<tr>
					<td><?= $result['name'] ?></td>
					<td><?= $result['name_code'] ?></td>
					<td><a href="<?= 'http://' . $_SERVER['SERVER_NAME'] . '/view/' . $result['name_id'] ?>" target="_blank"><?= $result['name_id'] ?></a></td>
					<td><?= MoneyFormat($result['price']) ?> đ</td>
					<td><img src="<?= $result['image'] ?>" width="100"></td>
					<td><?= $result['time_created'] ?></td>
					<td><?=$result['viewer']?></td>
					<td>
						<form method="post"><input type="text" hidden="" value="<?= $result['name_id'] ?>" name="ske_code_id"><a href="edit-code.php?name=<?= $result['name_id'] ?>" class="btn btn-primary">Chỉnh sửa</a>
							<button type="submit" class="btn btn-danger" name="delete">Xóa</button>
					</td>
					</form>
				</tr>
			<?php } ?>
		</tbody>
	</table>
	<div class="modal fade" tabindex="-1" id="create_new">
		<div class="modal-dialog modal-xl">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">Tạo code mới</h5>
					<button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body">
					<form method="post">
						<div class="form-group">
							<p>Tên code</p>
							<input type="text" class="form-control" name="name_code_new" required>
						</div>
						<br>
						<div class="form-group">
							<p>Đường liên kết</p>
							<input type="text" class="form-control" name="url_code_new" required>
						</div>
						<br>
						<div class="form-group">
							<p>Mã code</p>
							<input type="text" class="form-control" name="code_code_new" required>
						</div>
						<br>
						<div class="form-group">
							<p>Mệnh giá code</p>
							<input type="number" class="form-control" name="price_code_new" required>
						</div>
						<br>
						<div class="form-group">
							<p>Link ảnh</p>
							<input type="text" class="form-control" name="image_code_new" required>
						</div>
						<br>
						<div class="form-group">
							<p>Mô tả</p>
							<textarea class="form-control" name="details_code_new" id="ske_create">Mô tả tại đây</textarea>
						</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
					<button type="submit" class="btn btn-primary" name="create_new_code">Tạo mới</button>
					</form>
				</div>
			</div>
		</div>
	</div>
	</tbody>
	</table>
	<?php
	if (isset($_POST['delete'])) {
		$query = $ske_connect->query("DELETE FROM sources WHERE name_id = '$_POST[ske_code_id]'");
		if ($query) {
			echo '<script>window.location.href = "";</script>';
		} else {
			die("ERROR");
		}
	}
	if (isset($_POST['create_new_code'])) {
		$save1 = $ske_connect->query("INSERT INTO sources SET
			name = '$_POST[name_code_new]',
			name_id = '$_POST[url_code_new]',
			name_code = '$_POST[code_code_new]',
			price = '$_POST[price_code_new]',
			details = '$_POST[details_code_new]',
			image = '$_POST[image_code_new]',
			category_id = $_GET[id],
			viewer = 0,
			time_created = now()");
		if ($save1) {
			echo "Create Oke<script>window.location.href = ''</script>";
		} else {
			echo "Create Failed";
		}
	}
	?>
</div>
<?php
include 'footer.php';
?>