<?php
session_start();
if (!isset($_SESSION['admin'])) {
	die(header("Location: /ske_admin"));
}
include 'header.php';
include '../includes/Config.php';
?>
<div class="container mt-4">
	<button class="btn btn-success float-right" data-toggle="modal" data-target="#create_new">Tạo danh mục</button>
	<p>Bảng dữ liệu</p>
	<table class="table table-bordered hover">
		<thead>
			<tr>
				<th>ID</th>
				<th>Tên danh mục</th>
				<th>Mô tả</th>
				<th>Ảnh</th>
				<th>Liên kết</th>
				<th>Số mã nguồn</th>
				<th>Thao Tác</th>
			</tr>
		</thead>
		<tbody>
			<?php
			foreach (GetCategory() as $result) { ?>
				<tr>
					<td><?= $result['id'] ?></td>
					<td><?= $result['name'] ?></td>
					<td><?= $result['description'] ?></td>
					<td><img src="<?= $result['image'] ?>" width="100"></td>
					<td><a href="/view-category/<?= $result['link'] ?>" target="_blank"><?= $result['link'] ?></a></td>
					<td><?= $ske_connect->query('SELECT COUNT(*) FROM sources WHERE category_id = ' . $result['id'])->fetch_array()['COUNT(*)'] ?></td>
					<td>
						<a class="btn btn-success" href="view_code.php?id=<?= $result['id'] ?>">Xem mã nguồn</a>
						<form method="post">
							<input type="text" name="category_id" hidden value="<?= $result['id'] ?>">
							<button class="btn btn-danger" name="delete" type="submit">Xóa</button>
						</form>
					</td>
				<?php } ?>
				</tr>
		</tbody>
	</table>
	<div class="modal fade" tabindex="-1" id="create_new">
		<div class="modal-dialog modal-xl">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title">Tạo danh mục</h5>
					<button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body">
					<form method="post">
						<div class="form-group">
							<p>Tên danh mục</p>
							<input type="text" class="form-control" name="name_code_new" required>
						</div>
						<br>
						<div class="form-group">
							<p>Đường liên kết</p>
							<input type="text" class="form-control" name="url_code_new" required>
						</div>
						<div class="form-group">
							<p>Link ảnh</p>
							<input type="text" class="form-control" name="image_code_new" required>
						</div>
						<br>
						<div class="form-group">
							<p>Mô tả ngắn</p>
							<input type="text" name="details_code_new" class="form-control" required>
						</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
					<button type="submit" class="btn btn-primary" name="create_new_code">Tạo mới</button>
					</form>
				</div>
			</div>
		</div>
	</div>
	</tbody>
	</table>
	<?php
	if (isset($_POST['delete'])) {
		$query = $ske_connect->query("DELETE FROM category WHERE id = $_POST[category_id]");
		$query = $ske_connect->query("DELETE FROM sources WHERE category_id = $_POST[category_id]");
		if ($query) {
			echo '<script>window.location.href = ""</script>';
		} else {
			die("ERROR");
		}
	}
	if (isset($_POST['create_new_code'])) {
		$save1 = $ske_connect->query("INSERT INTO category SET
			name = '$_POST[name_code_new]',
			description = '$_POST[details_code_new]',
			link = '$_POST[url_code_new]',
			image = '$_POST[image_code_new]'");
		if ($save1) {
			echo "Create Oke<script>window.location.href = ''</script>";
		} else {
			echo "Create Failed";
		}
	}
	?>
</div>
<?php
include 'footer.php';
?>