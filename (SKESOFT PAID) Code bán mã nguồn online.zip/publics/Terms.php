<?php
include $_SERVER['DOCUMENT_ROOT'].'/includes/Config.php';
$access = 1;
$title = 'Chính sách sử dụng | Ske Software';
include '../includes/Header.php';
?>
<div class="container-fluid py-4">
	<div class="row mt-4">
		<div class="col-lg-7 mb-lg-0 mb-4">
			<div class="card">
				<div class="card-body p-3">
					<div class="row">
						<div class="col-lg-6">
							<div class="d-flex flex-column h-100">
								<p class="mb-1 pt-2 text-bold"><i class="fad fa-badge-dollar"></i> Ske Software</p>
								<h5 class="font-weight-bolder">Kiếm tiền từ đây</h5>
								<p class="mb-5">Hành trình kiếm tiền của bạn bắt đầu từ đây - Kiếm tiền bằng Website MMO</p>
							</div>
						</div>
						<div class="col-lg-5 ms-auto text-center mt-5 mt-lg-0">
							<div class="border-radius-lg h-100">
								<img src="/assets/img/shapes/waves-white.svg" class="position-absolute h-100 w-50 top-0 d-lg-block d-none" alt="waves">
								<div class="position-relative d-flex align-items-center justify-content-center h-100">
									<img class="w-50 position-relative z-index-2 pt-4" src="/assets/img/dollar.png" alt="rocket">
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-lg-5">
			<div class="card h-100 p-3">
				<div class="overflow-hidden position-relative border-radius-lg bg-cover h-100" style="background-image: url('/assets/img/ivancik.jpg');">
					<span class="mask bg-gradient-dark"></span>
					<div class="card-body position-relative z-index-1 d-flex flex-column h-100 p-3">
						<h5 class="text-white font-weight-bolder mb-4 pt-2">Chính sách</h5>
						<p class="text-white">Chính sách sử dụng của chúng tôi.</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="row my-4">
		<div class="col-xl-12">
			<div class="card h-100">
				<div class="card-body p-3">
					<div class="container cards-2" style="text-align: left;">
						<h3><b>Xin chào bạn,</b></h3>
						<blockquote>
							<p>Lời đầu xin chân thành cảm ơn bạn đã ghé thăm website của chúng tôi !</p>
						</blockquote>
						<h4><span><b>ĐIỀU KHOẢN SỬ DỤNG:</b></span></h4>
						<div><span>1. Khi bạn truy cập vào website có nghĩa là bạn đồng ý với các chính sách này.</span></div>
						<div>&nbsp;</div>
						<div><span>2. Trang web này có sử dụng cookie để làm tốt nhất trải nghiệm cho bạn.</span></div>
						<div></div>
						<h2><span style="font-size: 14px;"><b>BẢO HÀNH CODE</b></span></h2>
						<ul>
							<li><span>Trong quá trình bạn sử dụng code nếu gặp lỗi chúng tôi sẽ đổi 1-1 code cho bạn tránh trường hợp dùng code có trục trặc</span></li>
							<li>Trong trường hợp bạn chỉnh sửa code của chúng tôi, hãy tạo bản sao lưu của code tránh trường hợp code bị hỏng không dùng được - chúng tôi không hỗ trợ bảo hành trường hợp này !</li>
							<li>Không hỗ trợ cho trường hợp code đi tải free về trên mạng</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php include '../includes/Footer.php';?>