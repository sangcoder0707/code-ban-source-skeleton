<?php
include '../includes/Config.php';
if (isset($_POST['search_code_submit'])) {
	$name = PreventSql($_POST['search_code']);
	$category_id = PreventSql($_POST['category_id']);
	$query = $ske_connect->query("SELECT * FROM sources WHERE category_id = $category_id AND name COLLATE UTF8_GENERAL_CI LIKE '%$name%' ORDER BY time_created DESC");
	echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
        <span class="alert-icon"><i class="fad fa-search"></i></span>
        <span class="alert-text"><strong>Kết quả tìm kiếm: </strong> '.$name.'</span>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>';
	foreach ($query as $result) :?>
		<div class="col-sm-4">
			<div class="card mt-2">
				<div class="card-header p-0 mx-3 mt-3 position-relative z-index-1">
					<a href="/view/<?=$result['name_id']?>" class="d-block">
						<center><img src="<?=$result['image']?>" class="img-fluid img-thumbnail"></center>
					</a>
				</div>
				<div class="card-body pt-2">
					<center><div class="dropdown-divider mb-2" style="border-top: 1px solid rgb(0 255 31 / 20%) !important; width: 123px;"></div></center>
					<span class="text-gradient text-primary text-uppercase text-xs font-weight-bold my-2"><?=$result['price'] == 0 ? 'MIỄN PHÍ' : 'CÓ PHÍ'?></span>
					<a href="/view/<?=$result['name_id']?>" class="card-title h5 d-block text-darker">
						<?=$result['name_code']?>
					</a>
					<p class="card-description mb-4 text-sm">
						<?=$result['name']?>
					</p>
					<center><a class="btn btn-outline-secondary" href="/view/<?=$result['name_id']?>"><i class="fal fa-search"></i> &nbsp;Xem ngay</a></center>
					<hr>
					<div class="d-flex align-items-center">
						<img src="/assets/img/user.jpg" alt="..." class="avatar shadow">
						<div class="name ps-3">
							<span>Admin</span>
							<div class="stats">
								<small>Ngày phát hành: <?=date('d/m/Y', strtotime($result['time_created']))?></small>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php endforeach;
} else {
	die();
}